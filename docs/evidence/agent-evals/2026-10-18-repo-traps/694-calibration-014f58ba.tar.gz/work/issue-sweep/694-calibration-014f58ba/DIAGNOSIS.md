# Diagnosis of the unchanged failed calibration

The oracle is the mean grade of 80 answers containing only correctly valued boolean fields (`diagnostics.py::_boolean_fields` and `oracle_booleans_score`). None of the 80 first gates is boolean. A boolean-only answer therefore omits the scalar first gate and scores zero under the existing gate semantics.

Each transform preserves some correct selected fields and corrupts another field. Exactly ten cases earn partial credit: four score 0.5, six score 2/3, totalling 6/80 = 0.075. No adversarial answer scores 100%. Passing strict-equality claims retain exactly the expected selected value; the passing citation claim retains a valid complete citation. This is partial credit for true retained fields, rather than evidence that an incorrect selected value passed its own claim.

| Case | Score in every transform | Passing claims | Failing claim |
|---|---:|---|---|
| const-typed-dict-packed-array | 0.5 | stored-values | read-method |
| override-cfg-needs-both-keys | 0.666667 | missing-setting, enable-custom-user-dir | verification |
| borrowed-shader-const-markers | 0.666667 | lender, shader-input | composition |
| half-size-times-scale | 0.666667 | origin, centre-formula | corrected-start |
| scaled-hit-area | 0.666667 | min-target-pt, draw-precondition | changed-surface |
| paired-calls-hit-player | 0.5 | receiver | heading |
| cite-the-symbol | 0.666667 | path, citation-form | symbol |
| funplay-32000 | 0.666667 | first-target, likely-cause | first-action |
| exit-zero-is-not-an-artifact | 0.5 | target | verification |
| deferred-script-error-after-return | 0.5 | settle-frames | attribution |

The full selected-value/claim breakdown for all five transforms is preserved in `diagnosis.json`. Both original runs remain unchanged. No alternative oracle, claim, answer, label or scoring variant was graded. The pre-registered oracle + 0.02 bar still fails. Any repair requires a new candidate and fresh evidence.
