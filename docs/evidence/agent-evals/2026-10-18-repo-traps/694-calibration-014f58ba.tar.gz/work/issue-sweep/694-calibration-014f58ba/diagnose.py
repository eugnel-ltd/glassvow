#!/usr/bin/env python3
"""Read-only field/claim diagnosis of already-frozen, already-scored answers."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/glassvow/.claude/worktrees/sweep-repo-traps')
FRESH = Path('/workspace/work/issue-sweep/694-fresh-5b7138c0')


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, data):
    with path.open('x') as output:
        json.dump(data, output, indent=2, ensure_ascii=False)
        output.write('\n')


cases_path = ROOT/'tools/agent_evals/evals/repo_traps_structured/cases.jsonl'
cases = {r['id']:r for r in rows(cases_path)}
answers = rows(FRESH/'adversarial.jsonl')
graded = rows(OUT/'g-plain-1-adversarial.jsonl')
preflight = json.loads((OUT/'preflight.json').read_text())
for path, entry in preflight['frozen_files'].items():
    assert digest(Path(path)) == entry['sha256']
result = {
    'basis':'Existing run-1 grading bytes; run-2 outcomes are identical. No variant graded.',
    'candidate':preflight['candidate'],'cases_sha256':digest(cases_path),
    'answer_sha256':digest(FRESH/'adversarial.jsonl'),
    'labels_sha256':digest(FRESH/'adjudication/labels.jsonl'),
    'oracle_definition': {
        'implementation':'tools/agent_evals/diagnostics.py:oracle_booleans_score and _boolean_fields',
        'answer_construction':'For each case, include only fields whose equals value is a boolean, with their correct boolean value.',
        'aggregation':'Grade those boolean-only answers with the frozen grader and average equally over the 80 cases.',
        'reported_oracle_score':0.0,
        'cases':80,
        'boolean_first_gates':sum(isinstance(c['grader']['claims'][0].get('equals'),bool) for c in cases.values()),
        'first_gate_scalar_types':dict(Counter(type(c['grader']['claims'][0].get('equals')).__name__ for c in cases.values())),
        'explanation':'No first gate is a boolean field. The boolean-only oracle omits each scalar first gate, so the existing gate semantics produce zero. These are existing CLI metrics, not a new variant run.'
    },
    'transforms':{},
    'interpretation': {
        'credited_incorrect_selected_fields_found':False,
        'explanation':'The nonzero answers preserve correct selected scalar/boolean/citation fields while corrupting another field. Those retained fields pass their declared claims. The 0.075 is partial credit for retained true selections; this evidence does not show an incorrect selected value passing its own strict claim.',
        'scope':'Comparison is against frozen programmatic claim definitions, not a new independent semantic adjudication of adversarial answers.',
        'bar_verdict_unchanged':'FAIL: each transform exceeds the pre-registered oracle_booleans + 0.02 bar.'
    }
}
for kind in sorted({r['kind'] for r in graded}):
    subset = [r for r in graded if r['kind']==kind]
    nonzero=[]
    for grade in subset:
        if grade['score']<=0:
            continue
        answer = answers[grade['index']]['answer']
        claims = {c['id']:c for c in cases[grade['id']]['grader']['claims'] if not c.get('report_only')}
        breakdown=[]
        for claim_id,passed,_ in grade['verdicts']:
            claim = claims[claim_id]
            value = answer.get(claim['field'])
            if 'equals' in claim:
                matches = type(value) is type(claim['equals']) and value==claim['equals']
                predicate = {'kind':'strict equality','expected':claim['equals']}
            else:
                matches = isinstance(value,str) and re.fullmatch(claim['must_match'],value) is not None
                predicate = {'kind':'anchored citation pattern','pattern':claim['must_match']}
            if passed:
                assert matches, (grade['id'],claim_id)
            encoded=json.dumps(value,ensure_ascii=False).encode()
            breakdown.append({'claim_id':claim_id,'field':claim['field'],
                              'gate':bool(claim.get('gate')), 'passed':passed,
                              'predicate':predicate,
                              'selected_value':value if passed else str(value)[:160],
                              'selected_value_truncated':not passed and len(str(value))>160,
                              'selected_value_sha256':hashlib.sha256(encoded).hexdigest(),
                              'retained_correct_field':bool(passed and matches)})
        nonzero.append({'index':grade['index'],'id':grade['id'],'score':grade['score'],
                        'decision_failed':grade['decision_failed'],'claims':breakdown})
    result['transforms'][kind] = {
        'answers':len(subset),'nonzero_answers':len(nonzero),
        'full_score_answers':sum(r['score']>=1.0 for r in subset),
        'score_points':sum(r['score'] for r in subset),
        'mean':sum(r['score'] for r in subset)/len(subset),
        'score_distribution':dict(Counter(str(r['score']) for r in subset)),
        'nonzero_case_claim_breakdown':nonzero,
    }
assert result['oracle_definition']['boolean_first_gates']==0
write_new(OUT/'diagnosis.json',result)
example = result['transforms']['echo']
with (OUT/'DIAGNOSIS.md').open('x') as output:
    output.write('# Diagnosis of the unchanged failed calibration\n\n')
    output.write('The oracle is the mean grade of 80 answers containing only correctly valued boolean fields '
                 '(`diagnostics.py::_boolean_fields` and `oracle_booleans_score`). None of the 80 first gates is boolean. '
                 'A boolean-only answer therefore omits the scalar first gate and scores zero under the existing gate semantics.\n\n')
    output.write('Each transform preserves some correct selected fields and corrupts another field. '
                 'Exactly ten cases earn partial credit: four score 0.5, six score 2/3, totalling 6/80 = 0.075. '
                 'No adversarial answer scores 100%. Passing strict-equality claims retain exactly the expected selected value; '
                 'the passing citation claim retains a valid complete citation. This is partial credit for true retained fields, '
                 'rather than evidence that an incorrect selected value passed its own claim.\n\n')
    output.write('| Case | Score in every transform | Passing claims | Failing claim |\n|---|---:|---|---|\n')
    for row in example['nonzero_case_claim_breakdown']:
        passed=', '.join(c['claim_id'] for c in row['claims'] if c['passed'])
        failed=', '.join(c['claim_id'] for c in row['claims'] if not c['passed'])
        output.write(f'| {row["id"]} | {row["score"]:.6g} | {passed} | {failed} |\n')
    output.write('\nThe full selected-value/claim breakdown for all five transforms is preserved in `diagnosis.json`. '
                 'Both original runs remain unchanged. No alternative oracle, claim, answer, label or scoring variant was graded. '
                 'The pre-registered oracle + 0.02 bar still fails. Any repair requires a new candidate and fresh evidence.\n')
for path, entry in preflight['frozen_files'].items():
    assert digest(Path(path)) == entry['sha256']
write_new(OUT/'diagnostic-artifact-hashes.json', {
    path.name:{'sha256':digest(path),'bytes':path.stat().st_size}
    for path in sorted(OUT.iterdir()) if path.is_file()
})
print(json.dumps({'oracle':result['oracle_definition'],
                  'nonzero':{kind:{k:v for k,v in value.items() if k!='nonzero_case_claim_breakdown'}
                             for kind,value in result['transforms'].items()}},indent=2))
