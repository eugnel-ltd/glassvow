#!/usr/bin/env python3
"""Summarise immutable grading bytes; this never grades or changes any answer."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/glassvow/.claude/worktrees/sweep-repo-traps')
sys.path.insert(0, str(ROOT/'tools'))
from agent_evals.calibration import rate
from agent_evals.stats import BOOTSTRAP_RESAMPLES, STATS_SEED


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def bootstrap_means(by_case):
    """Resample whole cases; retain all rows within each sampled case."""
    clusters = list(by_case.values())
    random_source = random.Random(STATS_SEED)
    means = []
    for _ in range(BOOTSTRAP_RESAMPLES):
        sampled = [clusters[random_source.randrange(len(clusters))] for _ in clusters]
        means.append(sum(sum(group) for group in sampled)/sum(map(len, sampled)))
    means.sort()
    return [means[int(0.025*BOOTSTRAP_RESAMPLES)], means[int(0.975*BOOTSTRAP_RESAMPLES)-1]]


def write_new(path, data):
    with path.open('x') as output:
        json.dump(data, output, indent=2, ensure_ascii=False)
        output.write('\n')


metrics = json.loads((OUT/'metrics.json').read_text())
preflight = json.loads((OUT/'preflight.json').read_text())
assert json.loads((OUT/'postflight.json').read_text())['all_frozen_hashes_unchanged']
all_rows = {(name,run): rows(OUT/f'g-plain-{run}-{name}.jsonl')
            for name in ('correct-a','correct-b','wrong','adversarial') for run in (1,2)}
labels = rows(Path('/workspace/work/issue-sweep/694-fresh-5b7138c0/adjudication/labels.jsonl'))
label_index = {(r['set'],r['index'],r['claim_id']):r['label'] for r in labels}
supplement = {'created_utc':datetime.now(timezone.utc).isoformat(),
              'head':preflight['candidate'],'claims_sha256':metrics['claims_sha256'],
              'bootstrap':{'resamples':BOOTSTRAP_RESAMPLES,'seed':STATS_SEED,
                           'unit':'case','interval':'95% percentile'},
              'runs':{},'programmatic_retest':{},'judge_statistics':'not applicable: no scored judge claims'}
for run in (1,2):
    correct = metrics['runs'][f'plain/correct/run{run}']
    wrong = metrics['runs'][f'plain/wrong/run{run}']
    adversarial = metrics['runs'][f'plain/adversarial/run{run}']
    transforms = {}
    for kind, mean in adversarial['mean_by_transform'].items():
        values = [r for r in all_rows['adversarial',run] if r['kind']==kind]
        by_case = defaultdict(list)
        for row in values:
            by_case[row['id']].append(row['score'])
        transforms[kind] = {
            'answers':len(values),'mean':mean,
            'case_clustered_interval':bootstrap_means(by_case),
            'score_distribution':dict(Counter(str(r['score']) for r in values)),
            'at_100':rate((r['id'],r['score']>=1.0) for r in values),
            'nonzero_rows':[{'index':r['index'],'id':r['id'],'score':r['score']}
                            for r in values if r['score']>0],
            'oracle_booleans':adversarial['oracle_booleans'],
            'oracle_plus_002_limit':adversarial['oracle_booleans']+0.02,
            'oracle_plus_002_pass':mean<=adversarial['oracle_booleans']+0.02,
            'absolute_025_pass':mean<=0.25,
        }
    wrong_kinds = {}
    for kind in sorted({r['kind'] for r in all_rows['wrong',run]}):
        values = [r for r in all_rows['wrong',run] if r['kind']==kind]
        covered_pairs = [(r,cid,passed) for r in values for cid,passed,_ in r['verdicts']
                         if label_index['wrong',r['index'],cid]=='COVERED']
        wrong_kinds[kind] = {
            'answers':len(values),
            'coverage':rate((r['id'],any(label_index['wrong',r['index'],cid]=='COVERED'
                                       for cid,_,_ in r['verdicts'])) for r in values),
            'covered_programmatic_pass':rate((r['id'],passed) for r,_,passed in covered_pairs),
            'wrong_at_100':wrong['wrong_at_100_by_kind'][kind],
        }
    failure = correct['all']['claim_failure']
    bars = {
        'correct_no_decision_or_gate_failure':correct['all']['decision_or_gate_failures']==0,
        'correct_claim_false_negative_rate_le_005':failure['rate']<=0.05,
        'correct_claim_false_negative_wilson_upper_le_008':failure['wilson'][1]<=0.08,
        'no_covered_programmatic_claim_passes':len(wrong['covered_programmatic_passes'])==0,
        'wrong_at_100_rate_le_005':wrong['wrong_at_100']['rate']<=0.05,
        'wrong_at_100_wilson_upper_le_010':wrong['wrong_at_100']['wilson'][1]<=0.10,
        'wrong_coverage_ge_095':wrong['coverage']['rate']>=0.95,
        'all_transforms_mean_le_oracle_plus_002':all(t['oracle_plus_002_pass'] for t in transforms.values()),
        'all_transforms_mean_le_025':all(t['absolute_025_pass'] for t in transforms.values()),
    }
    supplement['runs'][str(run)] = {
        'bars':bars,'overall_verdict':'PASS' if all(bars.values()) else 'FAIL',
        'correct':correct,'wrong':wrong,'wrong_by_kind':wrong_kinds,'adversarial':transforms,
    }
for name in ('correct-a','correct-b','wrong','adversarial'):
    first,second = all_rows[name,1],all_rows[name,2]
    assert [r['index'] for r in first]==[r['index'] for r in second]
    assert [r['id'] for r in first]==[r['id'] for r in second]
    fields = ('score','decision_failed','judge_error','verdicts','reported_verdicts',
              'reported_judge_error','reported_judge_model_id','judge_model_id')
    changes = [{ 'index':one['index'],'id':one['id'],
                 'changed_fields':[field for field in fields if one[field]!=two[field]]}
               for one,two in zip(first,second)
               if any(one[field]!=two[field] for field in fields)]
    one_pass = {(r['index'],cid):passed for r in first for cid,passed,_ in r['verdicts']}
    two_pass = {(r['index'],cid):passed for r in second for cid,passed,_ in r['verdicts']}
    supplement['programmatic_retest'][name] = {
        'answers':len(first),'scored_claim_pairs':len(one_pass),
        'changed_answers':len(changes),'changed_claim_verdicts':sum(v!=two_pass[k] for k,v in one_pass.items()),
        'changes':changes,'exact_outcomes_equal':not changes,
        'mean_score_change':metrics['stability'][f'plain/{name}']['score_change'],
        'score_change_limit':0.025,
    }
supplement['overall_verdict'] = ('PASS' if all(run['overall_verdict']=='PASS' for run in supplement['runs'].values())
                                and all(r['exact_outcomes_equal'] for r in supplement['programmatic_retest'].values()) else 'FAIL')
supplement['limits'] = [
    'Fresh sets are now spent; no tuning or replacement performed.',
    'No model calls, judge calibration, approvals or hill-climb performed.',
    'No isolated Sonnet x3 baseline or current-hash inputs/grader approval exists from this experiment.',
    'CLI judge-majority and ballot-split empty denominators are not evidence of judge reliability.',
]
write_new(OUT/'summary.json',supplement)
run = supplement['runs']['1']
c,w = run['correct'],run['wrong']
with (OUT/'RESULT.md').open('x') as output:
    output.write('# Frozen #694 programmatic calibration: FAIL\n\n')
    output.write(f"Candidate `{preflight['candidate']}`; 1,040 answers over 80 cases, each graded twice offline. "
                 'All candidate, answer, label and protocol hashes were verified before grading and remained unchanged.\n\n')
    output.write('Both runs produced the same result. Every adversarial transform scored mean **0.075**, exceeding '
                 'the **0.02** limit (oracle booleans = 0). Each satisfies the separate 0.25 cap. '
                 'This failed bar prevents acceptance of the candidate.\n\n')
    output.write('| Bar | Measured result | Verdict |\n|---|---|---|\n')
    output.write(f"| Correct decision/gate failures | {c['all']['decision_or_gate_failures']}/320 | PASS |\n")
    output.write('| Correct claim false negatives | 2/552 = 0.362%; Wilson 95% [0.099%, 1.311%]; case-clustered [0%, 1.172%] | PASS |\n')
    output.write('| Hedged correct claim false negatives | 1/276 = 0.362%; Wilson 95% [0.064%, 2.023%]; case-clustered [0%, 1.172%] | PASS |\n')
    output.write('| COVERED programmatic claims passing wrong answers | 0/332 | PASS |\n')
    output.write('| Wrong answers scoring 100% | 0/320; Wilson upper 1.186%; case-clustered [0%, 0%] | PASS |\n')
    output.write('| Wrong-answer scored coverage | 320/320; Wilson lower 98.814%; case-clustered [100%, 100%] | PASS |\n')
    output.write('| Adversarial mean ≤ oracle + 0.02 | Every transform: 0.075 > 0.02 | FAIL |\n')
    output.write('| Adversarial mean ≤ 0.25 | Every transform: 0.075 | PASS |\n')
    output.write('| Deterministic test/retest | 0/1,040 changed outcomes; 0/1,794 changed scored-claim verdicts; mean score change 0 | PASS |\n\n')
    output.write('The two sub-100 correct answers share one non-gate claim: see `metrics.json` under `plain/correct/run1/all/under_100`. '
                 'They remain frozen; no answer or claim has been revised.\n\n')
    output.write('| Transform | Answers | Mean | 95% case-clustered interval |\n|---|---:|---:|---|\n')
    for kind,value in run['adversarial'].items():
        lo,hi=value['case_clustered_interval']
        output.write(f'| {kind} | {value["answers"]} | {value["mean"]:.3f} | [{lo:.4f}, {hi:.4f}] |\n')
    output.write('\nAll four wrong-answer kinds have 80/80 covered answers and 0/80 scoring 100%; '
                 'per-kind Wilson and case-clustered intervals are in `summary.json`. '
                 'Labels: 552 pairs, 332 COVERED, 220 UNCOVERED, 0 AMBIGUOUS.\n\n')
    output.write('Judge false-positive and ballot-flip bars are not applicable because no scored judge claims exist. '
                 'No external model, approval or hill-climb ran. Actual isolated Sonnet ×3 and current-hash approvals remain outstanding. '
                 'These single-use answer sets are now spent.\n\n')
    output.write('Reproduction: `run_calibration.py` captures exact CLI commands and hashes in `preflight.json`, '
                 '`commands.json` and `postflight.json`; `summarise.py` adds pre-registered bars and whole-case bootstrap intervals '
                 f'using {BOOTSTRAP_RESAMPLES} resamples and seed {STATS_SEED}. Existing grading outputs are never overwritten.\n')
hashes = {path.name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
          for path in sorted(OUT.iterdir()) if path.is_file()}
write_new(OUT/'artifact-hashes.json',hashes)
print(json.dumps({'overall_verdict':supplement['overall_verdict'],
                  'bars':run['bars'],'programmatic_retest':supplement['programmatic_retest'],
                  'out':str(OUT)},indent=2))
