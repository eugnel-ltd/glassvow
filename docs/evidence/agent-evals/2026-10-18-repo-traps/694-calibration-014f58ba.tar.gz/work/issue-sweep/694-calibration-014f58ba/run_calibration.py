#!/usr/bin/env python3
"""Frozen, offline, single-use #694 calibration; no candidate files are written."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/glassvow/.claude/worktrees/sweep-repo-traps')
FRESH = Path('/workspace/work/issue-sweep/694-fresh-5b7138c0')
PACKET = Path('/workspace/work/issue-sweep/694-blind-inputs-5b7138c0a924')
PROTOCOL = Path('/workspace/work/issue-sweep/694-fresh-set-protocol-5b7138c0a924.md')
OUT = Path(__file__).resolve().parent
HEAD = '014f58ba3c4a62bbb3c41e19944caae6df47a81d'
EXPECTED = {
    ROOT/'tools/agent_evals/evals/repo_traps_structured/cases.jsonl': '5b7138c0a9249b5fc09200a7ae3b375eebc73c432e805c79eeb6c31469a0568a',
    ROOT/'tools/agent_evals/evals/repo_traps_structured/split.json': '0e0944423bc9954f644f9b4417f689e12424fe75b4fb88c74a0f4c1c8002e516',
    PACKET/'MANIFEST.json': 'fe5884a90023bb67316cec1f3d0958f381c764b9862ec09f35db0192c4c6c5c7',
    PACKET/'questions.jsonl': '374cf201db9a2fcaea8488dd880c3f09aba94fe04c8091c1ccc38dfead88af20',
    PROTOCOL: 'db021960441a65a556f8057e7644daad7cf2b4233ce3a5fe7030f48a17d92333',
    FRESH/'correct-a.jsonl': '8003378334e67a1e2f5ab6912b8e2387a09168130ea84adc05a143a47a985949',
    FRESH/'correct-b.jsonl': '74e2dce254af156094cae45eb364d43cd74127c92d93f04a7e7b9fadafa36693',
    FRESH/'wrong.jsonl': 'f298a1db8482d6306ad01ac001229ab4fa532f46efcdc65366592e493ef1128f',
    FRESH/'adversarial.jsonl': '12b17c7c9d969f1c587570b9a5504fd4de3f3d6b36035a818687e516c0cec6c0',
    FRESH/'adjudication/scored-claims.jsonl': 'cb45f303fc55bcc960616faa06a56b9f85200d132a966cc1b19177693205f2f5',
    FRESH/'adjudication/labels.jsonl': '34238b480b3387d365f10073a731db08f658a08a7d03c747a3d611bd8a2a5a8a',
}
CLAIMS_SHA = '9d43d59793df7f5c5d9860024ad9c496a7669bf8fdfc95b455fd709a2476142e'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


sys.path.insert(0, str(ROOT/'tools'))
from agent_evals.calibration import rate, wilson, clustered_interval
from agent_evals.evalspec import load_eval, load_cases
from agent_evals.graders import claims_sha256, needs_judge
from agent_evals.stats import BOOTSTRAP_RESAMPLES, STATS_SEED

if (OUT/'preflight.json').exists():
    raise SystemExit('This evidence directory is single use; preflight already exists.')
assert git('rev-parse', 'HEAD') == HEAD
assert not git('status', '--porcelain', '--untracked-files=no'), 'Tracked candidate is dirty'
packet_manifest = json.loads((PACKET/'MANIFEST.json').read_text())
for relative, expected in packet_manifest['files'].items():
    assert digest(PACKET/relative) == expected, relative
for path, expected in EXPECTED.items():
    assert digest(path) == expected, str(path)
spec = load_eval('repo_traps_structured')
cases = load_cases(spec)
assert len(cases) == 80
assert claims_sha256(cases) == CLAIMS_SHA
assert needs_judge(cases, scored_only=True) is False
scored_claims = {case.id: [claim['id'] for claim in case.grader['claims']
                         if not claim.get('report_only')] for case in cases}
assert sum(map(len, scored_claims.values())) == 138
answers = {name: rows(FRESH/f'{name}.jsonl')
           for name in ('correct-a', 'correct-b', 'wrong', 'adversarial')}
expected_rows = {'correct-a': 160, 'correct-b': 160, 'wrong': 320, 'adversarial': 400}
for name, values in answers.items():
    assert len(values) == expected_rows[name]
    count = Counter(row['id'] for row in values)
    assert set(count) == set(scored_claims)
    assert set(count.values()) == {expected_rows[name]//80}
labels = rows(FRESH/'adjudication/labels.jsonl')
label_pairs = {(row['set'], row['index'], row['claim_id']) for row in labels}
expected_pairs = {('wrong', index, claim)
                  for index, row in enumerate(answers['wrong'])
                  for claim in scored_claims[row['id']]}
assert len(labels) == len(label_pairs) == 552
assert label_pairs == expected_pairs
assert Counter(row['label'] for row in labels) == {'COVERED':332, 'UNCOVERED':220}
source_files = sorted((ROOT/'tools/agent_evals').rglob('*.py'))
source_hashes = {str(path.relative_to(ROOT)): digest(path) for path in source_files}
preflight = {
    'created_utc': now(), 'candidate': HEAD, 'claims_sha256': CLAIMS_SHA,
    'protocol_read_before_scoring': True, 'scored_judge_backend_required': False,
    'external_calls_authorised': False,
    'frozen_files': {str(path): {'sha256': digest(path), 'bytes': path.stat().st_size}
                     for path in EXPECTED},
    'packet_files_verified': packet_manifest['files'], 'candidate_source_files': source_hashes,
    'answer_counts': {name: {'rows': len(values), 'cases': len({v['id'] for v in values}),
                             'kind': dict(Counter(v.get('kind') for v in values))}
                      for name, values in answers.items()},
    'scored_claims': 138, 'adjudication_pairs': len(labels),
    'labels': dict(Counter(row['label'] for row in labels)),
    'execution_plan': {'eval': 'repo_traps_structured', 'sets': list(answers),
                       'runs': [1,2], 'arm': 'plain', 'workers': 1, 'min_gain':0.05},
    'bar_source': str(PROTOCOL), 'note': 'Immutable single-use sets; no revisions after scores.'
}
write_new(OUT/'preflight.json', preflight)
commands = []
grading_paths = []
for name in answers:
    role = 'correct' if name.startswith('correct-') else name
    for run in (1,2):
        output = OUT/f'g-plain-{run}-{name}.jsonl'
        command = [sys.executable, '-B', 'tools/agent_evals/calibration.py', '--eval',
                   'repo_traps_structured', 'grade', '--answers', str(FRESH/f'{name}.jsonl'),
                   '--set', name, '--role', role, '--run', str(run), '--arm', 'plain',
                   '--workers', '1', '--out', str(output)]
        start = now()
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        commands.append({'command':command,'started_utc':start,'finished_utc':now(),
                         'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        if result.returncode:
            write_new(OUT/'commands.json',commands)
            raise SystemExit(f'Grading failed: {name} run {run}')
        grading_paths.append(output)
command = [sys.executable, '-B', 'tools/agent_evals/calibration.py', '--eval',
           'repo_traps_structured', 'metrics', '--gradings', *map(str, grading_paths),
           '--labels', str(FRESH/'adjudication/labels.jsonl'), '--min-gain','0.05',
           '--out',str(OUT/'metrics.json')]
start = now()
result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
commands.append({'command':command,'started_utc':start,'finished_utc':now(),
                 'exit_code':result.returncode,'stdout_bytes':len(result.stdout.encode()),
                 'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),
                 'stderr':result.stderr})
write_new(OUT/'commands.json',commands)
assert result.returncode == 0, 'Metrics failed'
for path, expected in EXPECTED.items():
    assert digest(path) == expected, f'Frozen file changed: {path}'
assert git('rev-parse','HEAD') == HEAD
assert not git('status','--porcelain','--untracked-files=no')
assert {str(p.relative_to(ROOT)):digest(p) for p in source_files} == source_hashes
write_new(OUT/'postflight.json', {'completed_utc':now(), 'all_frozen_hashes_unchanged':True,
                                 'candidate_head_unchanged':True,'candidate_source_unchanged':True,
                                 'external_model_calls':0,'paid_calls':0})
print(json.dumps({'out':str(OUT),'completed':True,'grading_files':len(grading_paths)},indent=2))
