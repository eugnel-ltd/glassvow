#!/usr/bin/env python3
"""Frozen, offline, single-use #694 calibration; no candidate files are written."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/glassvow/.claude/worktrees/sweep-repo-traps')
FRESH = Path('/workspace/work/issue-sweep/694-fresh-2d3eb9a4')
PACKET = Path('/workspace/work/issue-sweep/694-blind-inputs-2d3eb9a44ed5')
PROTOCOL = Path('/workspace/work/issue-sweep/694-fresh-set-protocol-2d3eb9a44ed5.md')
OUT = Path(__file__).resolve().parent
HEAD = '7a164ad943fa13d8d56adc91efffb09efe147317'
EXPECTED = {
    ROOT/'tools/agent_evals/evals/repo_traps_structured/cases.jsonl': '2d3eb9a44ed593e9860fc3cb26927f170383fb011f090e942c20d4be2eef9a2c',
    ROOT/'tools/agent_evals/evals/repo_traps_structured/split.json': 'cd5bc1f665dd0ab1626a433926cba73b1dd799b99dcaebaa0e88eb56a8fca006',
    PACKET/'MANIFEST.json': '4bb8e060f657c569a8a93f00cbb9e8ca2657bfafdbadb6c2723bb5cc583e623c',
    PACKET/'questions.jsonl': '030d86c0709dc52a15a12ca0f2bdfcafd512acdbf35dad48629b701f96a5536e',
    PROTOCOL: '7b8d9d316d51e8d3ea01e8436628c09ac543dd01fe3b7559be8594adf37622c7',
    FRESH/'correct-a.jsonl': '8dc6204ee6bbcf5c6f6fa51cddfca7af0cd266bf742f81a198a9d56cd7a96046',
    FRESH/'correct-b.jsonl': '8c9347120a8b20a2d60b7c1a6b8239ca739142ae866de89312af0cfb14c16a65',
    FRESH/'wrong.jsonl': 'e480fd6a0251ee9f6dbb2c7da048bc8356ad922ef97b2c3f69f1f2d8291a64d4',
    FRESH/'adversarial.jsonl': '7d14b183d6e65028f19915f6c09f90800327dd6d7bed3845d20e33774d542b50',
    FRESH/'adjudication/scored-claims.jsonl': '2dbd4f80c5a95830ad3a9a6ecf585a6f2c0a3076ea1c9cf7eaefc294e7e97594',
    FRESH/'adjudication/labels.jsonl': '81206e0859ef919296a7526ba720f9cbbf474778881599d15e6d55a4e1149e59',
}
CLAIMS_SHA = '402b46ec30db914db2243a6fda0888ea55a842064d0dada16a6c0d2ec3fba32b'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


sys.path.insert(0, str(ROOT/'tools'))
from agent_evals.calibration import rate, wilson, clustered_interval
from agent_evals.evalspec import load_eval, load_cases
from agent_evals.graders import claims_sha256, needs_judge
from agent_evals.stats import BOOTSTRAP_RESAMPLES, STATS_SEED

if (OUT/'preflight.json').exists():
    raise SystemExit('This evidence directory is single use; preflight already exists.')
PRESERVATION = Path('/workspace/work/issue-sweep/694-preserve-014f58ba.json')
REVIEW = Path('/workspace/work/issue-sweep/694-review-7a164ad9.md')
REFREEZE = Path('/workspace/work/issue-sweep/694-refreeze-7a164ad9.json')
preserved_files = json.loads(PRESERVATION.read_text())['files']
for preserved_path, expected_sha in preserved_files.items():
    assert digest(Path(preserved_path)) == expected_sha, preserved_path
review_text = REVIEW.read_text()
assert f'Head: `{HEAD}`' in review_text and 'Verdict: `APPROVE`' in review_text
refreeze = json.loads(REFREEZE.read_text())
assert refreeze['head'] == HEAD and refreeze['claims_sha256'] == CLAIMS_SHA
assert digest(ROOT/'tools/agent_evals/evals/repo_traps_structured/decision_gate_audit.jsonl') == refreeze['audit_sha256']
for metadata in (PRESERVATION, REVIEW, REFREEZE, FRESH/'answers-freeze.json'):
    EXPECTED[metadata] = digest(metadata)
assert git('rev-parse', 'HEAD') == HEAD
assert not git('status', '--porcelain', '--untracked-files=no'), 'Tracked candidate is dirty'
packet_manifest = json.loads((PACKET/'MANIFEST.json').read_text())
for relative, expected in packet_manifest['files'].items():
    assert digest(PACKET/relative) == expected, relative
for path, expected in EXPECTED.items():
    assert digest(path) == expected, str(path)
spec = load_eval('repo_traps_structured')
cases = load_cases(spec)
assert len(cases) == 80
assert claims_sha256(cases) == CLAIMS_SHA
assert needs_judge(cases, scored_only=True) is False
scored_claims = {case.id: [claim['id'] for claim in case.grader['claims']
                         if not claim.get('report_only')] for case in cases}
assert sum(map(len, scored_claims.values())) == 138
answers = {name: rows(FRESH/f'{name}.jsonl')
           for name in ('correct-a', 'correct-b', 'wrong', 'adversarial')}
expected_rows = {'correct-a': 160, 'correct-b': 160, 'wrong': 320, 'adversarial': 400}
for name, values in answers.items():
    assert len(values) == expected_rows[name]
    count = Counter(row['id'] for row in values)
    assert set(count) == set(scored_claims)
    assert set(count.values()) == {expected_rows[name]//80}
labels = rows(FRESH/'adjudication/labels.jsonl')
label_pairs = {(row['set'], row['index'], row['claim_id']) for row in labels}
expected_pairs = {('wrong', index, claim)
                  for index, row in enumerate(answers['wrong'])
                  for claim in scored_claims[row['id']]}
assert len(labels) == len(label_pairs) == 552
assert label_pairs == expected_pairs
assert Counter(row['label'] for row in labels) == {'COVERED':333, 'UNCOVERED':219}
source_files = sorted((ROOT/'tools/agent_evals').rglob('*.py'))
source_hashes = {str(path.relative_to(ROOT)): digest(path) for path in source_files}
preflight = {
    'created_utc': now(), 'candidate': HEAD, 'claims_sha256': CLAIMS_SHA,
    'independent_review': {'path':str(REVIEW),'sha256':digest(REVIEW),'verdict':'APPROVE'},
    'predecessor_preservation': {'manifest':str(PRESERVATION),'sha256':digest(PRESERVATION),'verified_files':len(preserved_files)},
    'source_context_limitations': json.loads((FRESH/'answers-freeze.json').read_text())['limitations'],
    'protocol_read_before_scoring': True, 'scored_judge_backend_required': False,
    'external_calls_authorised': False,
    'frozen_files': {str(path): {'sha256': digest(path), 'bytes': path.stat().st_size}
                     for path in EXPECTED},
    'packet_files_verified': packet_manifest['files'], 'candidate_source_files': source_hashes,
    'answer_counts': {name: {'rows': len(values), 'cases': len({v['id'] for v in values}),
                             'kind': dict(Counter(v.get('kind') for v in values))}
                      for name, values in answers.items()},
    'scored_claims': 138, 'adjudication_pairs': len(labels),
    'labels': dict(Counter(row['label'] for row in labels)),
    'execution_plan': {'eval': 'repo_traps_structured', 'sets': list(answers),
                       'runs': [1,2], 'arm': 'plain', 'workers': 1, 'min_gain':0.05},
    'bar_source': str(PROTOCOL), 'note': 'Immutable single-use sets; no revisions after scores.'
}
write_new(OUT/'preflight.json', preflight)
commands = []
grading_paths = []
for name in answers:
    role = 'correct' if name.startswith('correct-') else name
    for run in (1,2):
        output = OUT/f'g-plain-{run}-{name}.jsonl'
        command = [sys.executable, '-B', 'tools/agent_evals/calibration.py', '--eval',
                   'repo_traps_structured', 'grade', '--answers', str(FRESH/f'{name}.jsonl'),
                   '--set', name, '--role', role, '--run', str(run), '--arm', 'plain',
                   '--workers', '1', '--out', str(output)]
        start = now()
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        commands.append({'command':command,'started_utc':start,'finished_utc':now(),
                         'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        if result.returncode:
            write_new(OUT/'commands.json',commands)
            raise SystemExit(f'Grading failed: {name} run {run}')
        grading_paths.append(output)
command = [sys.executable, '-B', 'tools/agent_evals/calibration.py', '--eval',
           'repo_traps_structured', 'metrics', '--gradings', *map(str, grading_paths),
           '--labels', str(FRESH/'adjudication/labels.jsonl'), '--min-gain','0.05',
           '--out',str(OUT/'metrics.json')]
start = now()
result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
commands.append({'command':command,'started_utc':start,'finished_utc':now(),
                 'exit_code':result.returncode,'stdout_bytes':len(result.stdout.encode()),
                 'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),
                 'stderr':result.stderr})
write_new(OUT/'commands.json',commands)
assert result.returncode == 0, 'Metrics failed'
for path, expected in EXPECTED.items():
    assert digest(path) == expected, f'Frozen file changed: {path}'
for preserved_path, expected_sha in preserved_files.items():
    assert digest(Path(preserved_path)) == expected_sha, preserved_path
assert git('rev-parse','HEAD') == HEAD
assert not git('status','--porcelain','--untracked-files=no')
assert {str(p.relative_to(ROOT)):digest(p) for p in source_files} == source_hashes
write_new(OUT/'postflight.json', {'completed_utc':now(), 'all_frozen_hashes_unchanged':True,
                                 'candidate_head_unchanged':True,'candidate_source_unchanged':True,
                                 'external_model_calls':0,'paid_calls':0})
print(json.dumps({'out':str(OUT),'completed':True,'grading_files':len(grading_paths)},indent=2))
