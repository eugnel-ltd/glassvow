# Measured-head binding

This campaign ran on candidate
`7a164ad943fa13d8d56adc91efffb09efe147317`, as verified before and after its
eight grading commands. The measured cases SHA-256 is
`2d3eb9a44ed593e9860fc3cb26927f170383fb011f090e942c20d4be2eef9a2c`;
claims SHA-256 is
`402b46ec30db914db2243a6fda0888ea55a842064d0dada16a6c0d2ec3fba32b`.
All answer, label, protocol, source and review hashes are in `preflight.json`.

A later delivery head may add CI test wiring. That head did not directly run
this campaign. Reusing these observations requires an explicit evaluation-input
and scorer hash-equivalence check plus the appropriate review delta. This
receipt must not be relabelled or replaced, and the spent answers must not be
graded again to claim a new-head run.
