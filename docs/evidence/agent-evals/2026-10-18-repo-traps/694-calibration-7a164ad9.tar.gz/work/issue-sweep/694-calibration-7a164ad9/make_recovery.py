#!/usr/bin/env python3
"""Archive this measured receipt and its frozen inputs without altering them."""
from pathlib import Path
import gzip
import hashlib
import json
import tarfile

BASE=Path('/workspace')
OUT=Path(__file__).resolve().parent
FRESH=BASE/'work/issue-sweep/694-fresh-2d3eb9a4'
PACKET=BASE/'work/issue-sweep/694-blind-inputs-2d3eb9a44ed5'
ARCHIVE=BASE/'work/issue-sweep/recovery/694-calibration-7a164ad9.tar.gz'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


preflight=json.loads((OUT/'preflight.json').read_text())
assert preflight['candidate']=='7a164ad943fa13d8d56adc91efffb09efe147317'
for filename,entry in preflight['frozen_files'].items():
    assert digest(Path(filename))==entry['sha256'],filename
preservation=BASE/'work/issue-sweep/694-preserve-014f58ba.json'
for filename,expected in json.loads(preservation.read_text())['files'].items():
    assert digest(Path(filename))==expected,filename
for filename,entry in json.loads((OUT/'artifact-hashes.json').read_text()).items():
    assert digest(OUT/filename)==entry['sha256'],filename
files=sorted(set([p for directory in (OUT,FRESH,PACKET) for p in directory.rglob('*') if p.is_file()]+
                 [BASE/'work/issue-sweep'/name for name in (
                     '694-fresh-set-protocol-2d3eb9a44ed5.md','694-refreeze-7a164ad9.json',
                     '694-review-7a164ad9.md','694-preserve-014f58ba.json')]))
manifest={str(path.relative_to(BASE)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in files}
manifest_path=OUT/'recovery-inputs-manifest.json'
with manifest_path.open('x') as output:
    json.dump({'measured_head':preflight['candidate'],'files':manifest},output,indent=2)
    output.write('\n')
files.append(manifest_path)
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for path in sorted(files):
                info=archive.gettarinfo(str(path),arcname=str(path.relative_to(BASE)))
                info.uid=info.gid=0
                info.uname=info.gname=''
                info.mtime=0
                with path.open('rb') as content:
                    archive.addfile(info,content)
print(json.dumps({'archive':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,
                  'sha256':digest(ARCHIVE),'archived_files':len(files),
                  'metrics_sha256':digest(OUT/'metrics.json'),'summary_sha256':digest(OUT/'summary.json'),
                  'result_sha256':digest(OUT/'RESULT.md'),'manifest_sha256':digest(manifest_path),
                  'measured_head':preflight['candidate']},indent=2))
