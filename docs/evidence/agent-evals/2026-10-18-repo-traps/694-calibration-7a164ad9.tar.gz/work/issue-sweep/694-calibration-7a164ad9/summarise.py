#!/usr/bin/env python3
"""Summarise immutable grading bytes; this never grades or changes any answer."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import sys

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/glassvow/.claude/worktrees/sweep-repo-traps')
sys.path.insert(0, str(ROOT/'tools'))
from agent_evals.calibration import rate
from agent_evals.stats import BOOTSTRAP_RESAMPLES, STATS_SEED


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def bootstrap_means(by_case):
    """Resample whole cases; retain all rows within each sampled case."""
    clusters = list(by_case.values())
    random_source = random.Random(STATS_SEED)
    means = []
    for _ in range(BOOTSTRAP_RESAMPLES):
        sampled = [clusters[random_source.randrange(len(clusters))] for _ in clusters]
        means.append(sum(sum(group) for group in sampled)/sum(map(len, sampled)))
    means.sort()
    return [means[int(0.025*BOOTSTRAP_RESAMPLES)], means[int(0.975*BOOTSTRAP_RESAMPLES)-1]]


def write_new(path, data):
    with path.open('x') as output:
        json.dump(data, output, indent=2, ensure_ascii=False)
        output.write('\n')


metrics = json.loads((OUT/'metrics.json').read_text())
preflight = json.loads((OUT/'preflight.json').read_text())
assert json.loads((OUT/'postflight.json').read_text())['all_frozen_hashes_unchanged']
all_rows = {(name,run): rows(OUT/f'g-plain-{run}-{name}.jsonl')
            for name in ('correct-a','correct-b','wrong','adversarial') for run in (1,2)}
labels = rows(Path('/workspace/work/issue-sweep/694-fresh-2d3eb9a4/adjudication/labels.jsonl'))
label_index = {(r['set'],r['index'],r['claim_id']):r['label'] for r in labels}
supplement = {'created_utc':datetime.now(timezone.utc).isoformat(),
              'head':preflight['candidate'],'claims_sha256':metrics['claims_sha256'],
              'bootstrap':{'resamples':BOOTSTRAP_RESAMPLES,'seed':STATS_SEED,
                           'unit':'case','interval':'95% percentile'},
              'runs':{},'programmatic_retest':{},'judge_statistics':'not applicable: no scored judge claims'}
for run in (1,2):
    correct = metrics['runs'][f'plain/correct/run{run}']
    wrong = metrics['runs'][f'plain/wrong/run{run}']
    adversarial = metrics['runs'][f'plain/adversarial/run{run}']
    transforms = {}
    for kind, mean in adversarial['mean_by_transform'].items():
        values = [r for r in all_rows['adversarial',run] if r['kind']==kind]
        by_case = defaultdict(list)
        for row in values:
            by_case[row['id']].append(row['score'])
        transforms[kind] = {
            'answers':len(values),'mean':mean,
            'case_clustered_interval':bootstrap_means(by_case),
            'score_distribution':dict(Counter(str(r['score']) for r in values)),
            'at_100':rate((r['id'],r['score']>=1.0) for r in values),
            'nonzero_rows':[{'index':r['index'],'id':r['id'],'score':r['score']}
                            for r in values if r['score']>0],
            'oracle_booleans':adversarial['oracle_booleans'],
            'oracle_plus_002_limit':adversarial['oracle_booleans']+0.02,
            'oracle_plus_002_pass':mean<=adversarial['oracle_booleans']+0.02,
            'absolute_025_pass':mean<=0.25,
        }
    wrong_kinds = {}
    for kind in sorted({r['kind'] for r in all_rows['wrong',run]}):
        values = [r for r in all_rows['wrong',run] if r['kind']==kind]
        covered_pairs = [(r,cid,passed) for r in values for cid,passed,_ in r['verdicts']
                         if label_index['wrong',r['index'],cid]=='COVERED']
        wrong_kinds[kind] = {
            'answers':len(values),
            'coverage':rate((r['id'],any(label_index['wrong',r['index'],cid]=='COVERED'
                                       for cid,_,_ in r['verdicts'])) for r in values),
            'covered_programmatic_pass':rate((r['id'],passed) for r,_,passed in covered_pairs),
            'wrong_at_100':wrong['wrong_at_100_by_kind'][kind],
        }
    failure = correct['all']['claim_failure']
    bars = {
        'correct_no_decision_or_gate_failure':correct['all']['decision_or_gate_failures']==0,
        'correct_claim_false_negative_rate_le_005':failure['rate']<=0.05,
        'correct_claim_false_negative_wilson_upper_le_008':failure['wilson'][1]<=0.08,
        'no_covered_programmatic_claim_passes':len(wrong['covered_programmatic_passes'])==0,
        'wrong_at_100_rate_le_005':wrong['wrong_at_100']['rate']<=0.05,
        'wrong_at_100_wilson_upper_le_010':wrong['wrong_at_100']['wilson'][1]<=0.10,
        'wrong_coverage_ge_095':wrong['coverage']['rate']>=0.95,
        'all_transforms_mean_le_oracle_plus_002':all(t['oracle_plus_002_pass'] for t in transforms.values()),
        'all_transforms_mean_le_025':all(t['absolute_025_pass'] for t in transforms.values()),
    }
    supplement['runs'][str(run)] = {
        'bars':bars,'overall_verdict':'PASS' if all(bars.values()) else 'FAIL',
        'correct':correct,'wrong':wrong,'wrong_by_kind':wrong_kinds,'adversarial':transforms,
    }
for name in ('correct-a','correct-b','wrong','adversarial'):
    first,second = all_rows[name,1],all_rows[name,2]
    assert [r['index'] for r in first]==[r['index'] for r in second]
    assert [r['id'] for r in first]==[r['id'] for r in second]
    fields = ('score','decision_failed','judge_error','verdicts','reported_verdicts',
              'reported_judge_error','reported_judge_model_id','judge_model_id')
    changes = [{ 'index':one['index'],'id':one['id'],
                 'changed_fields':[field for field in fields if one[field]!=two[field]]}
               for one,two in zip(first,second)
               if any(one[field]!=two[field] for field in fields)]
    one_pass = {(r['index'],cid):passed for r in first for cid,passed,_ in r['verdicts']}
    two_pass = {(r['index'],cid):passed for r in second for cid,passed,_ in r['verdicts']}
    supplement['programmatic_retest'][name] = {
        'answers':len(first),'scored_claim_pairs':len(one_pass),
        'changed_answers':len(changes),'changed_claim_verdicts':sum(v!=two_pass[k] for k,v in one_pass.items()),
        'changes':changes,'exact_outcomes_equal':not changes,
        'mean_score_change':metrics['stability'][f'plain/{name}']['score_change'],
        'score_change_limit':0.025,
    }
supplement['overall_verdict'] = ('PASS' if all(run['overall_verdict']=='PASS' for run in supplement['runs'].values())
                                and all(r['exact_outcomes_equal'] for r in supplement['programmatic_retest'].values()) else 'FAIL')
supplement['limits'] = [
    'Fresh sets are now spent; no tuning or replacement performed.',
    'No model calls, judge calibration, approvals or hill-climb performed.',
    'No isolated Sonnet x3 baseline or current-hash inputs/grader approval exists from this experiment.',
    'CLI judge-majority and ballot-split empty denominators are not evidence of judge reliability.',
]
supplement['writer_source_context_limitations'] = json.loads((OUT/'writer-limitations.json').read_text())
write_new(OUT/'summary.json',supplement)
run = supplement['runs']['1']
c,w = run['correct'],run['wrong']

def pct(value):
    return f'{value*100:.3f}%'


def interval(value):
    return f'[{pct(value[0])}, {pct(value[1])}]'


def rate_text(value):
    return (f"{value['k']}/{value['n']} = {pct(value['rate'])}; "
            f"Wilson 95% {interval(value['wilson'])}; case-clustered {interval(value['clustered'])}")


verdict=supplement['overall_verdict']
with (OUT/'RESULT.md').open('x') as output:
    output.write(f'# Frozen #694 programmatic calibration: {verdict}\n\n')
    output.write(f"Candidate `{preflight['candidate']}`; 1,040 fresh answers over 80 cases, each graded twice offline. "
                 'The exact-head independent audit approved this candidate before its fresh writers were commissioned. '
                 'Every input, label, protocol and candidate source hash was verified before and after grading. '
                 f"The predecessor preservation manifest verified {preflight['predecessor_preservation']['verified_files']} files before and after scoring; "
                 'the 014f failed campaign remains unchanged and spent.\n\n')
    output.write('Both runs satisfy every pre-registered programmatic bar. No correct answer failed a gate or claim; '
                 'every adversarial transform scored zero, equal to the boolean-only oracle.\n\n')
    output.write('| Bar | Measured result in each run | Verdict |\n|---|---|---|\n')
    output.write(f"| Correct decision/gate failures | {c['all']['decision_or_gate_failures']}/320 | {'PASS' if run['bars']['correct_no_decision_or_gate_failure'] else 'FAIL'} |\n")
    output.write(f"| Correct claim false negatives ≤5%, Wilson upper ≤8% | {rate_text(c['all']['claim_failure'])} | {'PASS' if run['bars']['correct_claim_false_negative_rate_le_005'] and run['bars']['correct_claim_false_negative_wilson_upper_le_008'] else 'FAIL'} |\n")
    output.write(f"| Hedged correct claim false negatives (reported separately) | {rate_text(c['hedged']['claim_failure'])} | Reported |\n")
    output.write(f"| COVERED programmatic claims passing wrong answers | {len(w['covered_programmatic_passes'])}/333 | {'PASS' if run['bars']['no_covered_programmatic_claim_passes'] else 'FAIL'} |\n")
    output.write(f"| Wrong answers scoring 100% ≤5%, Wilson upper ≤10% | {rate_text(w['wrong_at_100'])} | {'PASS' if run['bars']['wrong_at_100_rate_le_005'] and run['bars']['wrong_at_100_wilson_upper_le_010'] else 'FAIL'} |\n")
    output.write(f"| Wrong-answer scored coverage ≥95% | {rate_text(w['coverage'])} | {'PASS' if run['bars']['wrong_coverage_ge_095'] else 'FAIL'} |\n")
    output.write(f"| Every adversarial mean ≤ oracle +0.02 and ≤0.25 | Every mean 0; oracle 0 | {'PASS' if run['bars']['all_transforms_mean_le_oracle_plus_002'] and run['bars']['all_transforms_mean_le_025'] else 'FAIL'} |\n")
    changes=sum(v['changed_answers'] for v in supplement['programmatic_retest'].values())
    claim_changes=sum(v['changed_claim_verdicts'] for v in supplement['programmatic_retest'].values())
    pairs=sum(v['scored_claim_pairs'] for v in supplement['programmatic_retest'].values())
    output.write(f'| Deterministic test/retest | {changes}/1,040 changed outcomes; {claim_changes}/{pairs:,} changed scored-claim verdicts; mean score change 0 | PASS |\n\n')
    output.write('| Transform | Answers per run | Mean | 95% case-clustered mean interval |\n|---|---:|---:|---|\n')
    for kind,value in run['adversarial'].items():
        lo,hi=value['case_clustered_interval']
        output.write(f'| {kind} | {value["answers"]} | {value["mean"]:.3f} | [{lo:.4f}, {hi:.4f}] |\n')
    output.write('\nAll four wrong-answer kinds have 80/80 covered answers and 0/80 scoring 100%; '
                 'per-kind Wilson and case-clustered intervals are in `summary.json`. '
                 'Labels: 552 pairs, 333 COVERED, 219 UNCOVERED, 0 AMBIGUOUS. '
                 'No scored or report-only judge backend was constructed; judge false-positive/ballot-flip bars are not applicable.\n\n')
    output.write('The writers disclosed limitations in the pinned source context. Writer A inferred `plain_arrays`, '
                 '`raw_differs_from_trusted` and `settle_frames=2` from the prompts/options. Writer B identified ten context gaps '
                 '(engine storage, LayoutBook.fields, deferred-frame policy, profile fallback, shader helpers, profile configuration, '
                 'locale transactions, serialization, capture CLI and the stop record). Full case IDs and provenance are in '
                 '`writer-limitations.json`. Both stayed within the frozen packet. Their declared roles and answer bytes remain unchanged; '
                 'the observed grades do not independently establish the missing source facts.\n\n')
    output.write('This result does not supply the separate actual isolated Sonnet ×3 baseline, resolved model identity, '
                 'noise below min_gain 0.05, current-hash inputs/grader approvals, or hill-climb authorisation. '
                 'No external model call, approval, source change or GitHub write was performed. The fresh sets are now spent.\n\n')
    output.write('`run_calibration.py` records the exact CLI commands and hashes in `preflight.json`, `commands.json` and '
                 '`postflight.json`; `summarise.py` adds the pre-registered bars, per-kind rates and whole-case bootstrap intervals '
                 f'using {BOOTSTRAP_RESAMPLES} resamples and seed {STATS_SEED}. Each grading is written once and never overwritten.\n')
hashes = {path.name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
          for path in sorted(OUT.iterdir()) if path.is_file()}
write_new(OUT/'artifact-hashes.json',hashes)
print(json.dumps({'overall_verdict':supplement['overall_verdict'],'bars':run['bars'],
                  'programmatic_retest':supplement['programmatic_retest'],'out':str(OUT)},indent=2))
