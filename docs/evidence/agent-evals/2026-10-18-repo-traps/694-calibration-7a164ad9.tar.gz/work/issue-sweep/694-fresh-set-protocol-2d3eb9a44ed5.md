# Fresh programmatic evidence for #694: parent coordinator only

Corpus freeze commit: 7a164ad943fa13d8d56adc91efffb09efe147317.
Final implementation candidate: 7a164ad943fa13d8d56adc91efffb09efe147317.
This freeze follows the once-through source audit of all 80 cases and 138 scored claims: 137 required decisions gate, and one optional Funplay cause hypothesis remains non-gating. Fifty-six gate flags were added; the font task prospectively defines its baseline-to-Label-top coordinate relation. Expected values, every answer, scorer, oracle and metrics are unchanged. The 014f campaign remains a measured FAIL and its sets are spent, as are all earlier campaigns. No prior set may be reused. No fresh writers or grading have run on this replacement. A new exact-head independent audit review is required before commissioning its fresh calibration.
Cases: 2d3eb9a44ed593e9860fc3cb26927f170383fb011f090e942c20d4be2eef9a2c.
Claims: 402b46ec30db914db2243a6fda0888ea55a842064d0dada16a6c0d2ec3fba32b.
Split SHA256: cd5bc1f665dd0ab1626a433926cba73b1dd799b99dcaebaa0e88eb56a8fca006.

Blind writer packet: /workspace/work/issue-sweep/694-blind-inputs-2d3eb9a44ed5/.
MANIFEST.json SHA256: 4bb8e060f657c569a8a93f00cbb9e8ca2657bfafdbadb6c2723bb5cc583e623c.
questions.jsonl SHA256: 030d86c0709dc52a15a12ca0f2bdfcafd512acdbf35dad48629b701f96a5536e.

The read-only packet contains task prompts and response shapes plus pinned repository
context. It excludes scorer code, claims, canonical references, source/why_hard fields,
author development answers and every spent set. Give writers only that packet and their
role brief, with no author transcript. Keep them from the candidate repository and grader.
The two correct writers must not see one another's answers. The claim author must not
generate or revise fresh answers. The packet contains no fresh answers.

## Minimum faithful size and boundaries

The current issue #694 bars apply to programmatic claims. The council's section 3 requires
at least four correct and four wrong answers per case. With 80 cases, the minimum is:

- Correct: 320 answers, at least two independent writers. A simple allocation is two
  distinct answers per case from each of two fresh writers (160 answers per writer).
  Preserve valid natural caveats in the unscored explanation and comply with the declared
  single-value fields. Do not give writers claims or expected answers.
- Wrong: 320 answers, four per case. Allocate one soft hedge, one retraction, one plausible
  sibling target and one wrong mechanism per case: 80 of each kind. The first two supply
  the council's two hedge/retraction cases per prompt. Vary retraction position across
  start, middle and end. A wrong example must challenge a decisive field; an erroneous
  unscored explanation beside correct structured choices does not establish a wrong
  scored decision. Writers decide correctness from the tasks and pinned context, never
  by querying the grader.
- Adversarial: five separately labelled transforms per case, 400 answers total: kitchen
  sink, soft hedge, padded wrong answer, echo and soup. Issue #694 names these five; the
  earlier council combined echo and soup. Preserve any explicitly correct booleans, but
  do not supply an oracle for the scalar choices. Keep wrong padding within the field cap
  where the intended test is robustness under that cap.
- Blind adjudication: after the claims and all answer sets are frozen, a fresh adjudicator
  labels every wrong-answer/scored-claim pair COVERED, AMBIGUOUS or UNCOVERED. It may read
  the frozen claim specification for this task, but receives no scores, grader feedback,
  author transcript or development answers. Report-only claims are excluded from scored
  coverage. Save labels and their hash before the first grading.

The bound is 1,040 fresh answers plus complete wrong/claim labels. This is an allocation
of the existing minimum, not permission to spend money or start a judge campaign. If a
writer cannot complete its allocation, record the shortfall; do not silently reduce it.
No pilot, claim tuning, new approval, statistical pass or baseline is authorised by this
file. Do not repair single-use sets after grading or select examples based on their score.

## Freeze before scoring

1. Verify the exact-head independent audit verdict, then the packet and candidate cases/claims hashes.
2. Collect each writer's output into a new file, with writer/role provenance. Hash the
   complete answer files before anyone grades them. Never replace a frozen file.
3. Have the independent adjudicator finish its labels; hash those labels before grading.
4. Only then grade these sets with the programmatic candidate. Its calibration CLI runs
   without constructing a model backend because every judge claim is report-only. Grade
   each set twice to observe deterministic repeatability. Use plain as the existing arm
   metadata; no judge ballot is requested and no new judge calibration takes place.
5. Compute the existing calibration.py metrics on these gradings and labels, preserving
   cases, claims, answers and labels hashes. This file supplies no measured result.

## Applicable bars

- No correct answer has a decision/gate failure. The council also retains claim false
  negatives <=5%, Wilson upper bound <=8%, with hedged correct answers reported apart.
- No COVERED programmatic claim passes a wrong answer.
- Wrong answers scoring 100% <=5%, Wilson upper bound <=10%.
- At least 95% of wrong answers have a COVERED scored claim.
- Each adversarial transform mean <= oracle_booleans +0.02 and <=0.25.
- Report Wilson and case-clustered intervals, per-kind results, ambiguity and deterministic
  test/retest results. Judge false-positive sample and ballot-flip bars are not applicable
  to this programmatic-only score. Reported judge claims remain unscored and uncalibrated.

Even a clean programmatic result does not supply the separate actual isolated Sonnet x3
baseline. That still needs a real provider, resolved identity, immutable inputs and measured
test noise below min_gain 0.05. Neither scripted unit tests nor other models can substitute.
No inputs/grader approval or hill-climb has been performed; the current-hash approval path
must be completed under its actual delegation after the required evidence is available.
